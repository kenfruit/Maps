﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parsing_html
{
    class Product
    {
        public string Img { get; set; }
        public string Title { get; set; }
        public string Link { get; set; }
    }
}
